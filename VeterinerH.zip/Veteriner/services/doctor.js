const doctor=[
    {name:"Niyazi Gül",expertise:0,status:false,animal:[]},
    {name:"Yasemin",expertise:3,status:false,animal:[]},
    {name:"Cabbar",expertise:1,status:false,animal:[]},
    {name:"Eleni",expertise:2,status:false,animal:[]},
]
