import React, { Component } from 'react';
import { InputList } from './input';

class App extends Component {
    render() {
        return (
          <div >
            <h3>Merhaba SüleyMAN </h3> <h2>   React App Denemesi </h2>
            <hr /> <br/>
            <InputList > < /InputList>
           </div>
        );
    }
}
export default App;
