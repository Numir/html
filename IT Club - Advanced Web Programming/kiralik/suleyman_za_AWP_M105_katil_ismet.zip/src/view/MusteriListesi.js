class MusteriListesi {
    constructor() {}
    start() {}
    stop() {}
}