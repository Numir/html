class MaktulListesi {
    constructor() {}
    start() {}
    stop() {}
}