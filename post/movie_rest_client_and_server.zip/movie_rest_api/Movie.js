class Movie{
    constructor(pId, pName, pPrice, pYear){
        this.id = pId;
        this.name = pName;
        this.price = pPrice;
        this.year = pYear;
    }
}


module.exports = Movie;