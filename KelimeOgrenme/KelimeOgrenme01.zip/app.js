let worte = ["der Amateur", "das Embargo ", "das Ambiente ", "der Amethyst ", "das Amphitheater ", "der Admiral ", "das Ammoniak ", "das Ammonium ", "das Ampere "];
let worte2 = ["Amatör", "Ambargo", "Ambiyans", "Ametist", "Amfi", "Amiral", "Amonyak", "Amonyum", "Amper"];

function renderMenu() {
    const ulMenus = worte.map(item => {
            return `<li  id="${item}" class="${item}">${item} 
<img id="${item}" class="${item}" src="./img/sag.png" alt="Ekle"></li>`;
        })
        .join('');
    addToDom(".menus", ulMenus);
}

function addToDom(selector, html) {
    document.querySelector(selector).innerHTML = html;
}
//renderMenu();
/**
 * Almaca kelimeler gelecek 1 adet
 */

function doldurMenu(menu) {
    const ulMenus = menu.map(item => {
            return `<li  id="${item}" class="${item}">${item} 
<img id="${item}" class="${item}" src="./img/sag.png" alt="Ekle"></li>`;
        })
        .join('');
    addToDom(".menus", menu);
}

function addToDom(selector, html) {
    document.querySelector(selector).innerHTML = html;
};
const randomWorte = worte[Math.floor(Math.random() * worte.length)];

function randomWorte2() {
    return worte2[Math.floor(Math.random() * worte2.length)]
};

function tekKelime() {
    document.querySelector(".menus").innerHTML = randomWorte;
};
tekKelime();

function cokluKelime() {
    let cevap = worte2[worte.indexOf(randomWorte)];
    let cevaplar = [];
    for (let index = 0; index < 3; index++) {
        cevaplar += "<li>" + randomWorte2() + "</li>";
        /**
         * TODO: dizi içinde kontrol olacak 
         * eğer varsa i-- olacak
         */
    }
    cevaplar += "<li>" + cevap + "</li>";
    //cevaplar.join("");
    /**
     * en değilde herhangi bir yerde olacak cevap.
     */
    // doldurMenu(cevaplar);

    return document.querySelector(".sepet").innerHTML = cevaplar;
};
cokluKelime();


function sonuc() {
    /***
     * TODO : menus ile seçilen sepet içindeki indexler aynı ise doğru yazdır.
     * değilse yanlış oluyor
     */
    document.querySelector(".cevap").innerHTML = cevaplar;
}

/***
 * 
 * 
Program akisi:
================
Program basladiginda daha önceden girilmis olan almanca kelimelerden bir tanesi secilerek ekranda
gösterilecek ve hemen bu kelimenin altinda 4 tane secenek sunulacak (bir tanesi mutlaka dogru olmali ;). 
Program her oturum basina toplam 8 soru soracak. Kullanici bir secenege tikladiginda tüm yanlislar ve
 dogru cevap gösterilecek ve kullanici puani güncellenecek. Puanlama bilgisi programin herhangi bir yerinde
  kullanicinin kac yanlis ve kac dogru yaptigi gösterilecek.

Kriterler:
================
- Programin düzgün calismasi
- Güzel bir dizayn (iyi bir css)
- Programin bir cok fonksiyona ayrilmasi
- Degisken ve fonksiyon isimlendirmelerinin dogru yapilmasi
- Data Model kullanilmasi
- InnerHTML ve Template Literallerin kullanilmasi
- find, filter, map gibi array metodlarinin kullanilmasi
- DOM Eventerinin kullanilmasi
- prompt, alert kullanilmamasi!
- Kod içine yorumların eklenmesi
- Indentation'lara (kod hizalama) azami önem verilmesi
- Kod icinde gereksiz bos satrilarin olmamasi
- Türkce karakterler kullanilmamasi
 */